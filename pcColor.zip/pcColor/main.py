# coding : UTF-8

import requests
from bs4 import BeautifulSoup
import mysql.connector

config = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': '123',
    'port': 3306,
    'database': 'mycolor',
    'charset': 'utf8'
}


print('连接到mysql服务器。。。')
cnx=mysql.connector.connect(**config)
print('连上了！')

hdrs = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Encoding': 'gzip, deflate, br',
'Accept-Language':'zh-CN,zh;q=0.9',
'Connection':'keep-alive',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
        }

url = "https://html-color-codes.info/color-names/"

r = requests.get(url,headers = hdrs)
soup = BeautifulSoup(r.content.decode('gbk','ignore'))
trs =soup.find_all('tr')
for tr in trs:
    cursor = cnx.cursor()
    print('插入数据')
    color_style = tr.get('style')
    tds = tr.find_all('td')
    td = [x for x in tds]
    color_name = td[0].text
    color_hex = td[1].text
    print('颜色: '+color_name+' 颜色值：'+color_hex+' 背景色样式: '+color_style)
    insert_color = ("INSERT INTO product" " (name,hex,style)" " VALUE (%s,%s,%s)")
    data_color = (color_name,color_hex,color_style)
    cursor.execute(insert_color,data_color)
    color_id = cursor.lastrowid
    print('插入了 id=',color_id)
    cnx.commit()
    cursor.close()
    print('*******完成此条插入！')
