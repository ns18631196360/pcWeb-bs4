package com.example.pcWeb.service.impl;


import com.example.pcWeb.dao.ColorMapper;
import com.example.pcWeb.entity.Color;
import com.example.pcWeb.persistent.ResultUtil;
import com.example.pcWeb.service.ColorService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public  class ColorServiceImpl implements ColorService {

        @Autowired
        private  ColorMapper mapper;

        public ResultUtil getAll(Integer page, Integer limit, Color color){
            PageHelper.startPage(page, limit);
            System.out.println("*******************这是page"+page);
            System.out.println("*******************这是limit"+limit);
            List<Color> list = mapper.selectColor();
            PageInfo<Color> pageinfo = new PageInfo<Color>(list);
            ResultUtil resultUtil = new ResultUtil();
            System.out.println("*******************这是count"+pageinfo.getTotal());
            resultUtil.setCode(0);
            resultUtil.setCount(pageinfo.getTotal());
            resultUtil.setData(pageinfo.getList());
            return resultUtil;
        }
}
