package com.example.pcWeb.dao;


import com.example.pcWeb.entity.Color;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ColorMapper {

    public List<Color> selectColor();
}
