package com.example.pcWeb.controller;

import com.example.pcWeb.entity.Color;
import com.example.pcWeb.persistent.ResultUtil;
import com.example.pcWeb.service.ColorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ColorController {
	@Autowired
    private ColorService colorService;

	Color color = new Color();

	@RequestMapping("getColor")
	@ResponseBody
	public ResultUtil getColor(Integer page, Integer limit, Color color){
		System.out.println("************进入了********");
		ResultUtil resultUtil = new ResultUtil();
		resultUtil = colorService.getAll(page,limit,color);
		System.out.println("************查询到了********");
		return resultUtil;
    }

	@RequestMapping("btn")
	public String btn(){
		System.out.println("************进入表格页面********");
		return "forward:2.html";
	}

	@RequestMapping("")
	public String index(){
		System.out.println("************进入首页********");
		return "forward:1.html";
	}
}
