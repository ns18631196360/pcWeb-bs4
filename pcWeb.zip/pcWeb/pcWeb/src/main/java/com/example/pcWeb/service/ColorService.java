package com.example.pcWeb.service;

import com.example.pcWeb.entity.Color;
import com.example.pcWeb.persistent.ResultUtil;

public interface ColorService {

    public ResultUtil getAll(Integer page, Integer limit, Color color);
}
